
<br><br><br>
<footer class="py-5 bg-dark">

    <div class="">
        <p class="m-0 text-center text-white">Copyright &copy; www.audible.com 2020</p>
        <p class="m-0 text-center text-white">This site is developed and hosted by Suria Yesmin Enath and Sadia Sultana</p>
        </div>
    </footer>    
  
    </body>
</html>
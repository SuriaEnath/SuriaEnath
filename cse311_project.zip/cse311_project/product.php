<?php
  
  include('partial-front/menu.php');

?>
<br>
<br>
<br>
<nr>
    <!-- products Search Section Starts Here -->
    <section class="products-search text-center">
        <div class="container">
            
            <form action="<?php echo SITEURL;?>products-search.php" method="POST">
                <input class="search_option" type="search" name="search" placeholder="Search for product.." required>
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
            </form>

        </div>
    </section>
    <!-- products sEARCH Section Ends Here -->



    <!-- products MEnu Section Starts Here -->
    <section class="product-menu">
        <div class="container">
            <h2 class="text-center">Product Menu</h2>

            <?php
            //display products that are active
            $sql = "SELECT *FROM tbl_products WHERE active ='yes'";

            $res=mysqli_query($conn,$sql);
            $count = mysqli_num_rows($res);
            if($count>0){
                    while($row=mysqli_fetch_assoc($res)){
                        $id=$row['id'];
                        $title=$row['title'];
                        $discription=$row['discription'];
                        $price=$row['price'];
                        $image_name=$row['image_name'];
                        ?>
                         <div class="products-menu-box">
                    <div class="products-menu-img">
                    <?php
                        if($image_name==""){
                            //image not available
                            echo "<div class='error'>image not available<?div>";
                        }else{
                            ?>
                             <img src="<?php echo SITEURL?>images/products/<?php echo $image_name?>" alt="Home Decor" class="img-responsive img-curve">

                            <?php

                        }
                    ?>
                       
                    </div>

                    <div class="product-menu-desc">
                        <h4><?php echo $title;?></h4>
                        <p class="product-price">TK <?php echo $price;?></p>
                        <p class="product-detail">
                        <?php echo $discription;?>
                        </p>
                        <br>

                        <a href="<?php echo SITEURL;?>order.php?product_id=<?php echo $id; ?>" class="btn btn-primary">Order Now</a>
                    </div>
            </div>
                        <?php
                    }
            }else{
                echo "<div class='error'>product not found</div>";
            }

?>

           



            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- product Menu Section Ends Here -->

    <?php
      include('partial-front/footer.php');
  ?>
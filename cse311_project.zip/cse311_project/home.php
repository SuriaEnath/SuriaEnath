<?php
  
  include('partial-front/menu.php');

?>
  <section id="banner_part">

<div class="banner_item">
    <iframe width="100%" height="700px" src="https://momento360.com/e/u/380033b1ec364ad28f8cc8bcf242120a?utm_campaign=embed&utm_source=other&heading=-8.27&pitch=25.92&field-of-view=75&size=medium" frameborder="0">
        </iframe>
    <div class="container">

        <div class="row justify-content-center text-center">
            <div class="col-lg-6">
                <div class="banner_text">

                    <h2>Order Your Products </h2>
                    <h1>Happy Shopping</h1>
                    <p>Getting product delivered right at your doorstep anytime anywhere is easier than ever.Place your order here. </p>
                    <a href="<?php echo SITEURL;?>product.php" style="margin-right: 30px;">Products MENU</a>
                    <a href="<?php echo SITEURL;?>shop.php">details</a>

                </div>
            </div>
        </div>
    </div>
</div>


</section>
        
    <!-- Products sEARCH Section Starts Here -->
    
    <section class="products-search text-center " >  
        <div class="container">          
            <form action="<?php echo SITEURL; ?>product-search.php" method="POST">
                <input class="search_option" type="search" name="search" placeholder="Search for product.." required>
                
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
            </form>

        </div>
    </section>
    <!-- product sEARCH Section Ends Here -->
    <?php
     if(isset($_SESSION['order'])){
         echo $_SESSION['order'];
         unset($_SESSION['order']);
     }
    ?>

      <!-- about part start -->
    <section id="about_part">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="about_text">
                        <h2>ABOUT US</h2>
                        <p>We deliver your needs

                            <span>“BUY HERE NOW” is an e-commerce outlet with 24/7 delivery service, conveniently delivered to your doorstep within 40 minutes of placing the order. Both 'cash on delivery' and ‘online payment’ are available for your convenience.</span>
                            <span>
                            Buy Here Now’s services can be availed at various locations within the Dhaka Metropolitan area, Mohakhali, Mohakhali DOHS, Banani DOHS, Baridhara DOHS, Banani, Gulshan 1 & 2, Baridhara, Bashundhara, Uttara & Dhanmondi.
                           </span>
                            <span>
                            We will deliver it to your door step whenever you require our service. Buy Here Now will ensure quality, convenience and affordability like no other.</span></p>
                    </div>
                </div>
            </div>
        </div>
    </section>




<!-- about part end -->

    <!-- CAtegories Section Starts Here -->
    <section class="categories">
        <div class="container">
            <h2 class="text-center">Explore Products</h2>
            <?php
            //create sql quary to display category from database
            $sql="SELECT * FROM tbl_category WHERE active='yes' AND featured='yes' LIMIT 3";
            $res = mysqli_query($conn,$sql);

            $count = mysqli_num_rows($res);
            if($count>0){
                 while($row=mysqli_fetch_assoc($res)){
                     $id = $row['id'];
                     $title = $row['title'];
                     $image_name = $row['image_name'];
                     ?>

            <a href="<?php echo SITEURL;?>category-products.php?category_id=<?php echo $id;?>">
                <div class="box-3 float-container">
                    <?php
                        if($image_name==""){
                            echo "<div class='error'>image not available</div>";
                        }else{
                            ?>
                            <img src="<?php echo SITEURL; ?>images/category/<?php echo $image_name ;?>" alt="Home Decor" class="img-responsive img-curve">
                            <?php
                        }
                    ?>
                   
                    <h3 class="float-text text-white"><?php echo $title;?></h3>
                </div>
            </a>


            <?php
                 }
            }
            else{
                echo"<div class='error'> Category not added.</div>";
            }

            ?>

           

            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->

    <!-- products MEnu Section Starts Here -->
    <section class="products-menu" >
        <div class="container">
            <h2 class="text-center">Products Menu</h2>
           
            

            <?php
            //Getting product from database
            $sql2 = "SELECT *FROM  tbl_product WHERE active='yes' AND featured='yes' LIMIT 6";

            $res2 = mysqli_query($conn,$sql2);
            $count2 = mysqli_num_rows($res2);
            if($count2>0)
            {
                while($row=mysqli_fetch_assoc($res2))
                {
                    $id = $row['id'];
                    $title = $row['title'];
                    $price = $row['price'];
                    $discription = $row['discription'];
                    $image_name = $row['image_name'];

                    ?>
                 <div class="product-menu-box" >
                    <div class="product-menu-img">
                    <?php
                        if($image_name==""){
                            echo "<div class='error'>image not available</div>";

                        }else{
                            ?>
                            <img src="<?php echo SITEURL?>images/product/<?php echo $image_name;?>" alt="Home Decor" class="img-responsive img-curve">
                            <?php

                        }
                    ?>
                        
                    </div>

                    <div class="product-menu-desc">
                        <h4><?php echo $title;?></h4>
                        <p class="product-price"><?php echo 'TK '.$price;?></p>
                        <p class="product-detail">
                        <?php echo $discription;?>
                        </p>
                        <br>

                        <a href="<?php echo SITEURL;?>order.php?product_id=<?php echo $id; ?>" class="btn btn-primary">Order Now</a>
                    </div>
                    
                </div>

                 <?php
                }

            }else{
                echo "<div class='error'>products not available.</div>";
            }


?>

         

           

            <div class="clearfix"></div>

            

        </div>

        <p class="text-center">
            <a href="product.php">See All Products</a>
        </p>
    </section>
    <!-- Products Menu Section Ends Here -->
     <!-- Team part start -->

    <section id="team_part">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center ">
                    <div class="team_head">
                        <h2>Our Team</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3">
                    <div class="team_inner">
                        <div class="team_text">
                            <h4>Delivery Team</h4>
                            <h5>delivery man, Happy Shopping</h5>
                            <p>Product Delivery Drivers transport  items from production areas to customers. A typical resume sample for this position mentions duties such as loading item, transporting it to the destination. </p>
                            <p></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="team_inner">
                        <div class="team_text">
                            <h4>Sadia Sultana</h4>
                            <h5>Executive team member, Happy Shopping</h5>
                            <p>Student of North South University
                                Department CSE, WOrking in marking department, Managing orders. </p>
                            <p></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="team_inner">
                        <div class="team_text">
                            <h4>Happy Shopping</h4>
                            <h5>Admin, Happy Shopping</h5>
                            <p> Owner of online_shop
                               Managing Admin Portal </p>
                            <p></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="team_inner">
                        <div class="team_text">
                            <h4>Suria Yesmin Enath</h4>
                            <h5>CEO, Happy Shopping</h5>
                            <p>Student of North South University
                                Department CSE, Graphices Designer,Web Designer,Basic programmer of c,Java.Currently Working on UI/UX </p>
                            <p></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<!--  Team part end -->
<!--  Review part start -->
    <section id="Review">
        <div class="gallry_head">
            <h2>Review</h2>
        </div>
            <div class="container">
                <div class="row  slider">

                    <div class="col-lg-6">
                        <div class="text_inner">
                            <img src="images/client-1.jpg" alt="">
                            <h4>Okita</h4>
                            <h5>Happy to shop here, won't be disappointed at all</h5>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>

                        </div>
                        <div class="text_text">
                            <p>I had to buy something new products. I must say that the sitting arrangements have been a bit kept closer, which I felt was uncomfortable. But the services and products are authentic and good.</p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="text_inner">
                            <img src="images/client-2.jpg" alt="">
                            <h4>Tasnia</h4>
                            <h5>phone</h5>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>

                        </div>
                        <div class="text_text">
                            <p> I think,i got authentic product from this online shop and packaging of my phone was very good with fast delivery .</p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="text_inner">
                            <img src="images/client-3.jpg" alt="">
                            <h4>Othoey</h4>
                            <h5>A good product option in Style_Eco</h5>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>

                        </div>
                        <div class="text_text">
                            <p>I got my organza kamiz from that shop and I will recommand that shop because their dress are really authentic and packaging was so nice.I will recomend this shop.</p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="text_inner">
                            <img src="images/client-2.jpg" alt="">
                            <h4>Mehedi Hassan</h4>
                            <h5>Gaming pc from Computer_lab</h5>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>
                            <a href="#"><i class="fas fa-star"></i></a>
                        </div>
                        <div class="text_text">
                            <p>Well i tried so many online shop for electronics device but all are fake.Here I want to try last time and I was satisfied.Love to shop here</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<!-- Review part end -->

<!--  Counter part start -->
    <section id="counter" style="background: url(image/counter-background.jpg);">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="countter_text">
                        <h3 class="counter_part">19999</h3>
                        <p>Total Orders</p>
                    </div>
                </div>
                <div class="col">
                    <div class="countter_text">
                        <h3 class="counter_part">569</h3>
                        <p>Reviews</p>
                    </div>
                </div>
                <div class="col">
                    <div class="countter_text">
                        <h3 class="counter_part">261</h3>
                        <p>product Category</p>
                    </div>
                </div>
                <div class="col">
                    <div class="countter_text">
                        <h3 class="counter_part">1500</h3>
                        <p>Products</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<!--  Counter part end -->

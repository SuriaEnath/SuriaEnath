<?php
  
  include('partial-front/menu.php');

?>

    <!-- Product sEARCH Section Starts Here -->
    <section class="product-search text-center">
        <div class="container">
        <?php
        $search = $_POST['search'];

        ?>
            
            <h2>Products on Your Search <a href="#" class="text-white">"<?php echo $search; ?>"</a></h2>

        </div>
    </section>
    <!-- product sEARCH Section Ends Here -->



    <!-- product MEnu Section Starts Here -->
    <section class="product-menu">
        <div class="container">
            <h2 class="text-center">Product Menu</h2>
            <?php 
              //get the search keyword
              
              //sql query to get product based on search keyword
              $sql = "SELECT * FROM tbl_product WHERE title LIKE '%$search%' OR discription LIKE '%$search%'";

              $res = mysqli_query($conn,$sql);
              $count = mysqli_num_rows($res);
              if($count>0){
                while($row=mysqli_fetch_assoc($res)){
                    $id=$row['id'];
                    $title=$row['title'];
                    $discription=$row['discription'];
                    $price=$row['price'];
                    $image_name=$row['image_name'];
                    ?>
                        <div class="product-menu-box">
                <div class="product-menu-img">
                <?php

                if($image_name==""){
                        echo "<div class='error'>Image not avaible</div>";
                }else{
                    ?>
                          <img src="<?php echo SITEURL;?>images/product/<?php echo $image_name?>" alt="Home Decor" class="img-responsive img-curve">
                    <?php

                }
                ?>
                  
                </div>

                <div class="product-menu-desc">
                    <h4><?php echo $title;?></h4>
                    <p class="product-price">TK <?php echo $price;?></p>
                    <p class="product-detail">
                    <?php echo $discription;?>
                    </p>
                    <br>

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>

                <?php

              }
            }
              
              else{
                echo "<div class='error'>Product not found</div>";
              }
            ?>

            
           

            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- Product Menu Section Ends Here -->

    <?php
      include('partial-front/footer.php');
  ?>
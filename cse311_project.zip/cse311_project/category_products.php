<?php
  
  include('partial-front/menu.php');

?>

<?php

//check whether id is passed or not
if(isset($_GET['category_id'])){
    $category_id = $_GET['category_id'];
    //get the category title based on category id
    $sql = "SELECT title FROM tbl_category WHERE id=$category_id";
    $res = mysqli_query($conn,$sql);
    $rows = mysqli_fetch_assoc($res);
    $category_title = $rows['title'];
}
else{
    header('location:'.SITEURL);
}

?>

    <!-- Products sEARCH Section Starts Here -->
    <section class="product-search text-center">
        <div class="container">
            
            <h2>Products on <a href="#" class="text-white">"<?php echo $category_title; ?>"</a></h2>

        </div>
    </section>
    <!-- Products sEARCH Section Ends Here -->



    <!-- Product MEnu Section Starts Here -->
    <section class="product-menu">
        <div class="container">
            <h2 class="text-center">Product Menu</h2>
            <?php 
                //sql qury to get product based on selected category
                $sql2 = "SELECT * FROM tbl_product WHERE category_id = $category_id";
                $res2= mysqli_query($conn,$sql2);
                $count2 = mysqli_num_rows($res2);
                if($count2>0){
                    while($row2=mysqli_fetch_assoc($res2)){
                        $id=$row2['id'];
                        $title = $row2['title'];
                        $price = $row2['price'];
                        $discription = $row2['discription'];
                        $image_name = $row2['image_name'];
                        ?>
                            <div class="product-menu-box">
                                <div class="product-menu-img">
                                <?php
                                     if($image_name==""){
                                        //image not available
                                        echo "<div class='error'>image not available<?div>";
                                    }else{
                                        ?>
                                         <img src="<?php echo SITEURL?>images/product/<?php echo $image_name?>" alt="Home Decor" class="img-responsive img-curve">
            
                                        <?php
            
                                    }
                                ?>
                                   
                                </div>

                                <div class="product-menu-desc">
                                    <h4><?php echo $title ; ?></h4>
                                    <p class="product-price">TK<?php echo $price ; ?></p>
                                    <p class="product-detail">
                                    <?php echo $discription ; ?>
                                    </p>
                                    <br>

                                    <a href="<?php echo SITEURL;?>order.php?product_id=<?php echo $id; ?>" class="btn btn-primary">Order Now</a>
                                </div>
                            </div>


                        <?php
                    }
                }else{
                    echo "<div class='error'>product not avaible</div>";
                }

?>

            
          


            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- Product Menu Section Ends Here -->

    <?php
      include('partial-front/footer.php');
  ?>
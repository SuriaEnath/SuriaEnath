
    <!-- Footer part start -->
    <footer id="footer_part" style="background: url(images/footer-banner.jpg);">
        <div class="col-lg-12">
            <div class="footer_logo">
                <a href="#"><img src="images/logo1.png" alt=""></a>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="footer_days">
                                    <h4>OPENING HOURS</h4>
                                    <ul>
                                        <li>Monday</li>
                                        <li>Tuesday</li>
                                        <li>Wednesdat</li>
                                        <li>Thursday</li>
                                        <li>Friday</li>
                                        <li>Saturday</li>
                                        <li>Sunday</li>
                                        <li>Holiday</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-8 footer_times">
                                <ul>
                                    <li>05.00 A.M. - 11.00 P.M.</li>
                                    <li>05.00 A.M. - 11.00 P.M.</li>
                                    <li>05.00 A.M. - 11.00 P.M.</li>
                                    <li>05.00 A.M. - 11.00 P.M.</li>
                                    <li>05.00 A.M. - 11.00 P.M.</li>
                                    <li>07.00 A.M. - 9.00 P.M.</li>
                                    <li>Closed</li>
                                    <li>Closed</li>
                                </ul>
                            </div>
                        </div>
                    </div>
            <div class="copy_right">
                <p>Copyright &copy; All right resorved by <span>Happy Shopping</span></p>
            </div>
        </div>
    </footer>
 <!-- Footer part end -->
    <script src="js/jquery-1.12.4.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/venobox.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/jquery.counterup.js"></script>
    <script src="js/script.js"></script>
</body>
</html>